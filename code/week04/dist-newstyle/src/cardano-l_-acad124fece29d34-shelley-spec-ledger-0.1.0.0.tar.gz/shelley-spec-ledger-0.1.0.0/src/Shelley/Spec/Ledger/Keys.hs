module Shelley.Spec.Ledger.Keys
  {-# DEPRECATED "Use 'import Cardano.Ledger.Keys' instead." #-}
  (module X)
where

import Cardano.Ledger.Keys as X
