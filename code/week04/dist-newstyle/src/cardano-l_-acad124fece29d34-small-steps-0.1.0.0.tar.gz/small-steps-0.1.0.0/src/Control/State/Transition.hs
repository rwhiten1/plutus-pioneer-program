-- | Small step state transition systems.
module Control.State.Transition
  ( module X )
where

import Control.State.Transition.Simple as X
